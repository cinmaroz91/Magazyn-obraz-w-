import { useState } from 'react';
import obrazyData from '../data/obrazy.json';

export default function Home() {
  const [obrazy, setObrazy] = useState(obrazyData);

  return (
    <div>
      <h1>Magazyn Obrazów</h1>
      <table>
        <thead>
          <tr>
            <th>Nazwa</th>
            <th>Typ montażu</th>
            <th>Fragment</th>
            <th>Lokalizacja</th>
            <th>Uwagi</th>
            <th>Status</th>
            <th>Dodał</th>
          </tr>
        </thead>
        <tbody>
          {obrazy.map((obraz, i) => (
            <tr key={i}>
              <td>{obraz.nazwa}</td>
              <td>{obraz.montaz}</td>
              <td>{obraz.fragment}</td>
              <td>{obraz.lokalizacja}</td>
              <td>{obraz.uwagi}</td>
              <td>{obraz.status}</td>
              <td>{obraz.autor}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}